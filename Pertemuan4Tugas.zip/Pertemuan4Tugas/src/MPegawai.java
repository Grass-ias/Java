/* Nama File : MPegawai.java
 * Deskripsi : program utama untuk menguji class Pegawai, Dosen, DosenTamu, DosenTetap, Tendik
 * Pembuat   : Ferdy Prasetya Putra/24060124140145
 * Tanggal   : 10/03/2026 
 */

import java.time.LocalDate;

public class MPegawai {
    public static void main(String[] args) {
        DosenTamu dtamu = new DosenTamu("D001", "Ir. Soekarno", LocalDate.of(1990, 5, 5), LocalDate.of(2015, 1, 1), 16000000.0, "Informatika", "NIDK123");
        DosenTetap dtetap = new DosenTetap("D002", "Pak Prabowo", LocalDate.of(1981, 6, 6), LocalDate.of(2025, 8, 10), 17000000.0, "Teknik", "NIDN456", 3500000.0);
        Tendik tendik = new Tendik("T001", "Mas Gibran", LocalDate.of(1985, 10, 1), LocalDate.of(2019, 5, 10), 9000000.0, "Bisnis", 2000000.0);

        System.out.println("Dosen Tamu");
        dtamu.printLaporan();
        System.out.println("NIP         : " + dtamu.getNIP());
        System.out.println("Nama        : " + dtamu.getNama());
        System.out.println("Fakultas    : " + dtamu.getFakultas());
        System.out.println("Gaji Pokok  : " + dtamu.getGajiPokok());
        System.out.println("Tunjangan   : " + dtamu.getTunjangan());
        System.out.println("Total Gaji  : " + (dtamu.getGajiPokok() + dtamu.getTunjangan()));
        System.out.println();

        System.out.println("Dosen Tetap");
        dtetap.printLaporan();
        System.out.println("NIP         : " + dtetap.getNIP());
        System.out.println("Nama        : " + dtetap.getNama());
        System.out.println("Fakultas    : " + dtetap.getFakultas());
        System.out.println("Gaji Pokok  : " + dtetap.getGajiPokok());
        System.out.println("BUP         : " + dtetap.getBUP());
        System.out.println("Tunjangan   : " + dtetap.getTunjangan());
        System.out.println("Total Gaji  : " + (dtetap.getGajiPokok() + dtetap.getTunjangan()));
        System.out.println();

        System.out.println("Tenaga Pendidikan");
        tendik.printLaporan();
        System.out.println("NIP         : " + tendik.getNIP());
        System.out.println("Nama        : " + tendik.getNama());
        System.out.println("Bidang      : " + tendik.getBidang());
        System.out.println("Gaji Pokok  : " + tendik.getGajiPokok());
        System.out.println("Tunjangan   : " + tendik.getTunjangan());
        System.out.println("Total Gaji  : " + (tendik.getGajiPokok() + tendik.getTunjangan()));
    }
}